Read the lab03 specs
Look for TODO throughout the code - tasks in random order
1) create stateHosp data
2) aggregate hospital data to state (without rating)
3) compile and test that aggreagated hospital without rating
4) write rating class (think about edge cases)
5) test aggregation of hospitals with rating
6) work on sorting to pass test
