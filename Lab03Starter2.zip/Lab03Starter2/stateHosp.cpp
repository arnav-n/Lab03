#include "stateHosp.h"
#include "hospitalData.h"
#include <sstream>
#include <string>
#include <assert.h>

 //TODO implement state hospital data

