#ifndef STATEH_H
#define STATEH_H

#include <memory>
#include <string>
#include <iostream>
#include "hospitalData.h"

/*
  class to represent state hospital data - fairly redundent at this point but will use
  inheritence next
*/
class stateHosp {
  //TODO implement
public:
  string getState() const { return "fixMe"; }
};
#endif
